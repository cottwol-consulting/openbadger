#if 0
  mbedtls_gcm_update(&aes,64,(const unsigned char*)output, fin);
  mbedtls_gcm_free( &aes );
  for (int i = 0; i < strlen(input); i++) {  
    char str[3];
    sprintf(str, "%c", (int)fin[i]);
    Serial.print(str);
  }
#endif


#include <stdio.h>
#include <string.h>
#include <PCSC/wintypes.h>
#include <PCSC/pcsclite.h>
#include <PCSC/winscard.h>
#include <mbedtls/gcm.h>
#include <openbadger-common.h>
#include <ob-crypto.h>


int main
  (int argc,
  char *argv [])

{
  unsigned char additional_authenticated_data [1024];
  unsigned char auth_tag [8];
  int ciphertext_length;
  unsigned char cleartext [1024];
  int cleartext_length;
  unsigned char decrypt_auth_tag [1024];
  unsigned char decrypted_text [1024];
  mbedtls_gcm_context key_context;
  int i;
  unsigned char iv [96/8 /* OB_CRYPTO_GCM_IV_LENGTH */];
  unsigned char key [OB_CRYPTO_AES256_LENGTH];
  unsigned char output [1024];
  unsigned char saved_ciphertext [1024];
  int status;


  status = ST_OK;

  memset(output, 0, sizeof(output));
memset(key, 0x17, sizeof(key));
memset(iv, 0x41, sizeof(iv));
memset(decrypted_text, 0, sizeof(decrypted_text));
strcpy((char *)cleartext, "Hello, Galois");
cleartext_length = strlen((char *)cleartext);

  mbedtls_gcm_init(&key_context);
  mbedtls_gcm_setkey(&key_context, MBEDTLS_CIPHER_ID_AES , key, OB_CRYPTO_AES256_LENGTH*8);
  mbedtls_gcm_starts(&key_context, MBEDTLS_GCM_ENCRYPT, iv, sizeof(iv), additional_authenticated_data, 0);
  mbedtls_gcm_update(&key_context, cleartext_length, cleartext, output);
  mbedtls_gcm_finish(&key_context, auth_tag, sizeof(auth_tag));

  fprintf(stderr, "Cleartext to be encrypted:\n");
  for (i=0; i<cleartext_length; i++)
  {
    fprintf(stderr, " %02X", cleartext [i]);
  };
  fprintf(stderr, "\n");
  fprintf(stderr, "Ciphertext:\n");
  memcpy(saved_ciphertext, output, cleartext_length);
  ciphertext_length = cleartext_length;
  for (i=0; i<64; i++)
  {
    fprintf(stderr, " %02X", output [i]);
    if (7 EQUALS (i % 8))
      fprintf(stderr, "\n");
  };
  fprintf(stderr, "\n");
  mbedtls_gcm_free(&key_context);

  fprintf(stderr, "Ciphertext to be decrypted:\n");
  for (i=0; i<ciphertext_length; i++)
  {
    fprintf(stderr, " %02X", saved_ciphertext [i]);
  };
  fprintf(stderr, "\n");
  mbedtls_gcm_init(&key_context);
  mbedtls_gcm_setkey(&key_context, MBEDTLS_CIPHER_ID_AES , key, OB_CRYPTO_AES256_LENGTH*8);
  mbedtls_gcm_starts(&key_context, MBEDTLS_GCM_DECRYPT, iv, sizeof(iv), additional_authenticated_data, 0);
  mbedtls_gcm_update(&key_context, ciphertext_length, saved_ciphertext, decrypted_text);
  mbedtls_gcm_finish(&key_context, decrypt_auth_tag, sizeof(decrypt_auth_tag));
  for (i=0; i<128; i++)
  {
    fprintf(stderr, " %02X", decrypted_text [i]);
  };
  fprintf(stderr, "\n");
  mbedtls_gcm_free(&key_context);

  return(status);
}

